const fs = require('fs');
const path = require('path');

// ชี้ไปที่ไฟล์ permissions.json ตามที่คุณกำหนด
const dbPath = path.join(__dirname, 'user-data.json');

if (!fs.existsSync(dbPath)) {
  fs.writeFileSync(dbPath, JSON.stringify({ users: [] }, null, 2));
}

function loadDB() {
  return JSON.parse(fs.readFileSync(dbPath, 'utf8'));
}

function saveDB(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

// เช็คสิทธิ์: เป็นแอดมิน หรือ มีไอดีในฐานข้อมูล
function hasPermission(userId, superAdminId) {
  if (userId === superAdminId) return true;
  const data = loadDB();
  return data.users.some(user => user.id === userId);
}

function addUser(userId, realName, nickName) {
  const data = loadDB();
  if (!data.users.some(user => user.id === userId)) {
    data.users.push({ id: userId, realName, nickName });
    saveDB(data);
    return true;
  }
  return false;
}

function removeUser(userId) {
  const data = loadDB();
  const before = data.users.length;
  data.users = data.users.filter(user => user.id !== userId);
  saveDB(data);
  return before !== data.users.length;
}

function getAllUsers() {
  return loadDB().users;
}

module.exports = { hasPermission, addUser, removeUser, getAllUsers };

