const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

function getCommands() {
  return [
    new SlashCommandBuilder()
      .setName('settext')
      .setDescription('• ส่งข้อความ Embed (สำหรับผู้มีสิทธิ์)')
      .addStringOption(opt => opt.setName('text').setDescription('•™ข้อความ').setRequired(true))
      .addStringOption(opt => opt.setName('color').setDescription('• สี').setRequired(true)
        .addChoices(
{ name: '[ ✓ ] :: แดง', value: '#ff0000' },
{ name: '[ ✓ ] :: เขียว', value: '#008000' },
{ name: '[ ✓ ] :: น้ำเงิน', value: '#0000ff' },
{ name: '[ ✓ ] :: เหลือง', value: '#ffff00' },
{ name: '[ ✓ ] :: ส้ม', value: '#ffa500' },
{ name: '[ ✓ ] :: ม่วง', value: '#800080' },
{ name: '[ ✓ ] :: ชมพู', value: '#ff1493' },
{ name: '[ ✓ ] :: ฟ้า', value: '#00bfff' },
{ name: '[ ✓ ] :: น้ำตาล', value: '#8b4513' },
{ name: '[ ✓ ] :: ดำ', value: '#000000' },
{ name: '[ ✓ ] :: ขาว', value: '#ffffff' },
{ name: '[ ✓ ] :: เทา', value: '#808080' },
{ name: '[ ✓ ] :: เขียวมะนาว', value: '#32cd32' },
{ name: '[ ✓ ] :: น้ำเงินเข้ม', value: '#000080' },
{ name: '[ ✓ ] :: แดงเข้ม', value: '#8b0000' },
{ name: '[ ✓ ] :: ทอง', value: '#ffd700' },
{ name: '[ ✓ ] :: ส้มอิฐ', value: '#d2691e' },
{ name: '[ ✓ ] :: คราม', value: '#4b0082' }
))
      .addChannelOption(opt => opt.setName('channel').setDescription('• เลือกห้อง').setRequired(true))
  ];
}

async function handle(interaction) {
  if (interaction.commandName === 'settext') {
    const text = interaction.options.getString('text');
    const color = interaction.options.getString('color');
    const channel = interaction.options.getChannel('channel');

    const embed = new EmbedBuilder().setDescription(text).setColor(color);
    await channel.send({ embeds: [embed] });
    return interaction.reply({ content: "[ ✓ ] ส่งข้อความแล้ว!", ephemeral: true });
  }
}

module.exports = { getCommands, handle };

