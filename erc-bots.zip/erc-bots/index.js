const { 
    Client, 
    GatewayIntentBits, 
    SlashCommandBuilder, 
    REST, 
    Routes, 
    MessageFlags 
} = require('discord.js');
const config = require('./config.json');
const permissions = require('./database/user-manager');
const messageBot = require('./cmd-bots/message-cmd');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });

async function registerAllCommands() {
    const commands = [
        ...messageBot.getCommands(),
        new SlashCommandBuilder().setName('sys-add-user').setDescription('• เพิ่มผู้ใช้').addUserOption(o => o.setName('u').setRequired(true).setDescription('ผู้ใช้')).setDefaultMemberPermissions(0),
        new SlashCommandBuilder().setName('sys-delete-user').setDescription('• ลบผู้ใช้').addUserOption(o => o.setName('u').setRequired(true).setDescription('ผู้ใช้')).setDefaultMemberPermissions(0),
        new SlashCommandBuilder().setName('sys-check-user-data').setDescription('• ดูฐานข้อมูล User').setDefaultMemberPermissions(0),
        new SlashCommandBuilder().setName('shutdown-bot').setDescription('• ปิดบอท').setDefaultMemberPermissions(0)
    ];

    const rest = new REST({ version: '10' }).setToken(config.token);
    try {
        await rest.put(Routes.applicationCommands(config.clientId), { body: commands.map(c => c.toJSON()) });
    } catch (error) {
        console.error('Error registering commands:', error);
    }
}

// เปลี่ยนจาก 'ready' เป็น 'clientReady' เพื่อลด Warning
client.once('clientReady', (c) => { 
    console.log(`[ ONLINE ] ${c.user.tag}`); 
    registerAllCommands(); 
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const isSuperAdmin = interaction.user.id === config.superAdminId;

    if (['sys-add-user', 'sys-delete-user', 'sys-check-user-data', 'shutdown-bot'].includes(interaction.commandName)) {
        if (!isSuperAdmin) {
            return interaction.reply({ content: "[ × ] ไม่อนุญาต!", flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.commandName === 'sys-add-user') {
            const target = interaction.options.getMember('u');
            // ตรวจสอบว่ามี User หรือไม่ก่อนเข้าถึง .id
            if (!target) return interaction.reply({ content: "[ × ] ไม่พบผู้ใช้รายนี้!", flags: [MessageFlags.Ephemeral] });
            
            permissions.addUser(target.id, target.user.username, target.displayName);
            return interaction.reply({ content: `[ ✓ ] เพิ่ม ${target.displayName} แล้ว!`, flags: [MessageFlags.Ephemeral] });
        }
        
        if (interaction.commandName === 'sys-delete-user') {
            const target = interaction.options.getUser('u');
            if (!target) return interaction.reply({ content: "[ × ] ไม่พบข้อมูลผู้ใช้", flags: [MessageFlags.Ephemeral] });
            
            permissions.removeUser(target.id);
            return interaction.reply({ content: `[ ✓ ] ลบ ID: ${target.id} ออกจากระบบแล้ว!`, flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.commandName === 'sys-check-user-data') {
            const list = permissions.getAllUsers().filter(u => u.id !== config.superAdminId);
            if (list.length === 0) return interaction.reply({ content: "[ × ] ไม่มีผู้ใช้ในระบบ!", flags: [MessageFlags.Ephemeral] });
            const res = list.map((u, i) => `${i + 1}. NickName:  ${u.nickName} | RealName: ${u.realName} | ID: ${u.id}`).join('\n');
            return interaction.reply({ content: `**รายชื่อผู้ใช้:**\n${res}`, flags: [MessageFlags.Ephemeral] });
        }

        if (interaction.commandName === 'shutdown-bot') {
            await interaction.reply({ content: "[ / ] ปิดระบบ...\n[ ✓ ] ปิดระบบแล้ว!", flags: [MessageFlags.Ephemeral] });
            process.exit();
        }
    }

    // ตรวจสอบสิทธิ์ผู้ใช้ปกติ
    if (!permissions.hasPermission(interaction.user.id, config.superAdminId)) {
        return interaction.reply({ content: "[ × ] คุณไม่มีสิทธิ์!", flags: [MessageFlags.Ephemeral] });
    }

    await messageBot.handle(interaction);
});

client.login(config.token);

